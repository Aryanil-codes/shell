#ifndef SP_TOK_H
#define SP_TOK_H

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#include<fcntl.h>
#include <unistd.h>

#include"sp_tok.h"
#include"execute.h"


void bg_exec(char *inp){
    char* token;

    char tokens[100][100];
    int count = 0;
    token = strtok(inp, " ");
    while(token != NULL){
        strcpy(tokens[count], token);
        token = strtok(NULL, " ");
        count++;
    }

    bg(count, tokens);
    
}

void fg_exec(char *inp,char *buffer_cwd,char *current_dir){
    char* token ;

    char tokens[100][100];
    int count = 0;
    token = strtok(inp, " ");
    while(token != NULL){
        strcpy(tokens[count], token);
        token = strtok(NULL, " ");
        count++;
    }

    fg(count, tokens,buffer_cwd,current_dir);
    
}

#endif