#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#include<fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <unistd.h>

#include"execute.h"

void execute(int count, char tokens[100][100]) {
    // Null-terminate the token array for execvp
    char *args[count + 2];  // +2 for the command and NULL terminator
    for (int i = 0; i < count; i++) {
        // args[i] = tokens[i];
        args[i]= tokens[i];
        printf("count - %d\n",count);
        printf("args[%d]: %s\n", i, args[i]);
    }
    args[count] = NULL;  // NULL terminator for execvp
    args[count + 1] = NULL; // Safety NULL pointer at the end

    int fake_pid = fork();
    if (fake_pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    } 
    else if (fake_pid == 0) {
        // Child process
        execvp(args[0], args);
        // If execvp fails
        perror("execvp failed");
        exit(EXIT_FAILURE);
    } else {
        // Parent process
        wait(NULL);
    }
}
