#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>

void reveal(int number_of_args,char args[][100]);