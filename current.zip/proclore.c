#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>


void proclore(int count, char commands[][100]){
    if(count==0){
        int shell_pid = getpid();
        FILE *fp = fopen("","r");
    }
}