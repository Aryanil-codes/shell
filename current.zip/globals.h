extern char buffer_cwd[900];
extern char dash_cmd[4096];
