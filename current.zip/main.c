#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#include"hop.h"
#include"token.h"
#include"reveal.h"

#include<fcntl.h>
#include <unistd.h>

int main(){

    char buffer_sys[100];
    char buffer_cwd[900];
    char current_dir[900];
    char username[2046];
    char* sysname;
    char inp[1024];

    int hostname = gethostname(buffer_sys,sizeof(buffer_sys));
    if(hostname==-1){     //write error conditions for the gethostname()
        perror("something's going wrong with gethostname()");
    }

    int errcode_username = getlogin_r(username,sizeof(username));
    if(errcode_username==-1){
        perror("error in getusername function");
    }

    getcwd(buffer_cwd,sizeof(buffer_cwd));

    //the termianl at work
    while(1){ //impleentation the looks of the terminal
        
    
        getcwd(current_dir,sizeof(current_dir));

        // printf("%ld , %ld",strlen(current_dir),strlen(buffer_cwd)); //debug purposes 

        if(strlen(current_dir)<strlen(buffer_cwd)){
            printf("\033[0;33m<%s@%s:\033[0;35m%s\033[1;0m>",username,buffer_sys,current_dir);
            fgets(inp,1024,stdin);
            inp[strlen(inp)-1]='\0';
        }
        else{
            char final_cwd[1024];
            int len = strlen(buffer_cwd);
            final_cwd[0] = '~';
            for (int i = len; i < strlen(current_dir); i++)
            {
                final_cwd[i-len+1] = current_dir[i];
            }
            final_cwd[strlen(current_dir)-len+2] = '\0';
            
            printf("\033[0;33m<%s@%s:\033[0;35m%s\033[1;0m>",username,buffer_sys,final_cwd);
            fgets(inp,1024,stdin);
            inp[strlen(inp)-1]='\0';

        }

        //------------------------------------------------------------------------------------------------------------------------------------------------
        //hereonwards pass to the tokenize fxn;

        char* token;

        token = strtok(inp," ");

        char tokens[100][100];
        int count = 0;
        while(token){
            strcpy(tokens[count],token);
            token = strtok(NULL," ");
            count++;
        }

    
        //tokenize done and hop called

        if (!strcmp(tokens[0],"hop"))
        {
            // printf("%d, %s,%s",count,tokens[1],buffer_cwd);
            hop(count-1,tokens,buffer_cwd,current_dir);
        }
        else if(!strcmp(tokens[0],"reveal")){
            reveal(count-1,tokens);
        }
        else if (!strcmp(tokens[0],"proclore"))
        {
            proclore(count-1,tokens);
        }
        else{
            execute(count,tokens);
        }
        
        

        
        


        // if(!strcmp("hop\n",inp)){
        //     printf("hello\n");
        // }
        // else{
        //     printf("wuts the cmd\n");
        // }



    }
    
    

    
    
   
    return 0;
}