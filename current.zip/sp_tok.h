#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#include<fcntl.h>
#include <unistd.h>

void bg_exec(char *inp);

void fg_exec(char *inp,char *buffer_cwd,char *current_dir);