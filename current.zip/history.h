#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

void store_history(char inp[1024]);
int count_lines();
void history();
void read_last_lines(const char *filename, int n);

