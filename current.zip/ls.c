#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <dirent.h>  // For directory operations
#include <sys/stat.h>  // For file information
#include <unistd.h>  // For getcwd
#include <pwd.h>  // For user info
#include <grp.h>  // For group info
#include <time.h>  // For formatting time


